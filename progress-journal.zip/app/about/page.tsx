import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart, Users, Lightbulb, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="font-serif text-4xl sm:text-5xl font-bold text-foreground mb-6 text-balance">
            About Progress Journal
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed text-pretty">
            We believe that personal growth happens through intentional reflection. Progress Journal was created to
            provide a peaceful, private space where you can explore your thoughts, track your development, and celebrate
            your journey.
          </p>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-muted/20">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-6">Our Mission</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                In our fast-paced world, it's easy to lose sight of our personal growth and the progress we're making.
                We created Progress Journal to help you slow down, reflect meaningfully, and recognize the positive
                changes in your life.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Whether you're working toward specific goals, processing life experiences, or simply want to develop a
                mindful writing practice, our platform provides the tools and environment to support your journey.
              </p>
            </div>
            <div className="flex justify-center">
              <div className="w-80 h-80 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-full flex items-center justify-center">
                <Heart className="h-24 w-24 text-primary" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-6xl">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-4">Our Values</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              Everything we do is guided by these core principles that shape how we approach personal growth and
              journaling.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center border-border">
              <CardHeader className="pb-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-semibold">Mindfulness</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="leading-relaxed">
                  We believe in the power of present-moment awareness and intentional reflection to create lasting
                  positive change in your life.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-border">
              <CardHeader className="pb-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-semibold">Privacy</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="leading-relaxed">
                  Your thoughts and reflections are deeply personal. We're committed to keeping your journal entries
                  completely private and secure.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center border-border">
              <CardHeader className="pb-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Lightbulb className="h-8 w-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-semibold">Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="leading-relaxed">
                  We're dedicated to helping you recognize patterns, celebrate progress, and develop insights that
                  support your personal development.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/20">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-6">Why We Built This</h2>
          </div>

          <div className="prose prose-lg max-w-none text-muted-foreground">
            <p className="text-lg leading-relaxed mb-6">
              Progress Journal was born from a simple observation: many of us struggle to recognize our own growth and
              progress. We get caught up in daily routines and challenges, often forgetting to pause and reflect on how
              far we've come.
            </p>
            <p className="text-lg leading-relaxed mb-6">
              Traditional journaling apps felt either too complex or too simplistic. We wanted to create something that
              struck the perfect balance—sophisticated enough to provide meaningful insights, yet simple enough to use
              every day without friction.
            </p>
            <p className="text-lg leading-relaxed">
              The result is a platform that combines the timeless practice of journaling with modern design principles
              and gentle technology that supports rather than distracts from your reflection practice.
            </p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="container mx-auto max-w-4xl text-center">
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-foreground mb-6">
            Start Your Reflection Practice
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            Join our community of mindful individuals who are committed to personal growth through intentional
            reflection.
          </p>
          <Button size="lg" className="text-base px-8 py-3" asChild>
            <Link href="/" className="flex items-center gap-2">
              Get Started
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
