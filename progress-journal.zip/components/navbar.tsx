"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { BookOpen, User, LogOut } from "lucide-react"
import { useState } from "react"

export function Navbar() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  const handleAuthAction = () => {
    setIsAuthenticated(!isAuthenticated)
  }

  return (
    <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Brand */}
          <Link
            href="/"
            className="flex items-center gap-2 font-playfair font-bold text-xl text-foreground hover:text-primary transition-colors"
          >
            <BookOpen className="h-6 w-6 text-primary" />
            Progress Journal
          </Link>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-6">
            <Link
              href="/"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Home
            </Link>
            <Link
              href="/about"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              About
            </Link>
            {isAuthenticated && (
              <Link
                href="/dashboard"
                className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Dashboard
              </Link>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <ModeToggle />
            <Button
              onClick={handleAuthAction}
              variant={isAuthenticated ? "outline" : "default"}
              size="sm"
              className="flex items-center gap-2"
            >
              {isAuthenticated ? (
                <>
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Sign Out</span>
                </>
              ) : (
                <>
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">Sign In</span>
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </nav>
  )
}
